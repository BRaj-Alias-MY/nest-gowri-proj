import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-eventslist',
  templateUrl: './eventslist.page.html',
  styleUrls: ['./eventslist.page.scss'],
})
export class EventslistPage implements OnInit {
  EVENTS_URL = 'http://localhost:3000/events/getAllEvent'
  eventslist: any

  constructor(private http: HttpClient, private route: Router) { }
  goBack() {
    this.route.navigate(['/home'])
  }

  ngOnInit() {
    this.getEventList().subscribe(response => {
      console.log(response)
      this.eventslist = response
    }, err => { console.log(err) })

  }
  getEventList() {
    return this.http.get(this.EVENTS_URL)
  }
  createvent() {
    this.route.navigate(['/eventvalue'])
  }

}

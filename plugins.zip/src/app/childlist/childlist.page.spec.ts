import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChildlistPage } from './childlist.page';

describe('ChildlistPage', () => {
  let component: ChildlistPage;
  let fixture: ComponentFixture<ChildlistPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChildlistPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChildlistPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

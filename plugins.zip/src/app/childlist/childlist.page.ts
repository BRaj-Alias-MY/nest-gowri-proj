import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-childlist',
  templateUrl: './childlist.page.html',
  styleUrls: ['./childlist.page.scss'],
})
export class ChildlistPage implements OnInit {
  CHILD_URL = 'http://localhost:3000/child/getAllChild'
  childList: any
  constructor(private http: HttpClient, private route: Router) { }

  ngOnInit() {
    this.getChildList().subscribe(response => {
      console.log(response)
      this.childList = response
    }, err => { console.log(err) })
  }
  getChildList() {
    return this.http.get(this.CHILD_URL)
  }
  createChild() {
    this.route.navigate(['/childvalue'])
  }
  goBack() {
    return this.route.navigate(['/home'])
  }
  showChildById(childId){
    console.log(childId)
  }

}

import { Component} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage{

  constructor(private activatedRoute: Router) { }

  childUrl(){
    this.activatedRoute.navigate(['/childvalue'])
  }

}

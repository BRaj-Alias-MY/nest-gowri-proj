import { Events } from './events';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-eventvalue',
  templateUrl: './eventvalue.page.html',
  styleUrls: ['./eventvalue.page.scss'],
})
export class EventvaluePage implements OnInit {
  events: Events;
  EVENT_POST_URL = "http://localhost:3000/events/createEvent";
  result: any;
  event: Events
  constructor(private route: Router, private http: HttpClient) {
    this.event = new Events()
  }

  ngOnInit() {
  }

  addEvent(eventForm) {

    this.event.event_title = eventForm.value['eventTitle']
    this.event.event_date = eventForm.value['eventDate']
    this.event.age_group = eventForm.value['age']
    this.event.trigger_date = eventForm.value['triggerDate']

    if (this.event.event_title != '') {
      return this.http.post(this.EVENT_POST_URL, this.event).subscribe(response => {
        this.result = 'Added Successfully!';


      }, err => { console.log(err) })
    }
    this.clearAll()


  }
  goBack() {
    this.route.navigate(['/eventslist'])
  }
  clearAll() {
    this.event.event_title = ''
    this.event.event_date = ''
    this.event.age_group = 0
    this.event.trigger_date = ''

  }

}

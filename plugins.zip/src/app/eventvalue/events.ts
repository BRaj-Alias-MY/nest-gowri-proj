export class Events {
    eventId?: number;
    event_title: string;
    event_date: string;
    age_group: number;
    trigger_date: string;
    isActive?: boolean;

}
import { Component, OnInit } from '@angular/core';
import { Child } from './child'
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-childvalue',
  templateUrl: './childvalue.page.html',
  styleUrls: ['./childvalue.page.scss'],
})
export class ChildvaluePage {
  child: Child;
  CHILD_POST_URL = "http://localhost:3000/child/createChild";
  result: any;
  constructor(private route: Router, private http: HttpClient) {
    this.child = new Child()
  }

  ngOnInit() {

  }
  addChild(childForm) {

    this.child.child_name = childForm.value['childName']
    this.child.father_name = childForm.value['fatherName']
    this.child.mother_name = childForm.value['motherName']
    this.child.phone = childForm.value['phoneNumber']
    this.child.email = childForm.value['email']
    this.child.age = childForm.value['age']
    if (this.child.child_name != '') {
      return this.http.post(this.CHILD_POST_URL, this.child).subscribe(response => {
        this.result = 'Added Successfully!';
        this.child.child_name = '';

      }, err => { console.log(err) })
    }

    this.child.child_name = ''
  }
  goBack() {
    this.route.navigate(['/childlist'])
  }
}

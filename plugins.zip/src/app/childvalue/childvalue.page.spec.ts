import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChildvaluePage } from './childvalue.page';

describe('ChildvaluePage', () => {
  let component: ChildvaluePage;
  let fixture: ComponentFixture<ChildvaluePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChildvaluePage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChildvaluePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

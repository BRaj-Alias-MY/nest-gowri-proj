export class Child {
    childId?: number;
    child_name: string;
    father_name: string;
    mother_name: string;
    phone: string;
    email: string;
    age: number;
    isActive?: boolean;
}
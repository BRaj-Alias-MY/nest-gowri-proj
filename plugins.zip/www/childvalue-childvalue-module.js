(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["childvalue-childvalue-module"],{

/***/ "./src/app/childvalue/childvalue.module.ts":
/*!*************************************************!*\
  !*** ./src/app/childvalue/childvalue.module.ts ***!
  \*************************************************/
/*! exports provided: ChildvaluePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChildvaluePageModule", function() { return ChildvaluePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _childvalue_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./childvalue.page */ "./src/app/childvalue/childvalue.page.ts");







var routes = [
    {
        path: '',
        component: _childvalue_page__WEBPACK_IMPORTED_MODULE_6__["ChildvaluePage"]
    }
];
var ChildvaluePageModule = /** @class */ (function () {
    function ChildvaluePageModule() {
    }
    ChildvaluePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_childvalue_page__WEBPACK_IMPORTED_MODULE_6__["ChildvaluePage"]]
        })
    ], ChildvaluePageModule);
    return ChildvaluePageModule;
}());



/***/ }),

/***/ "./src/app/childvalue/childvalue.page.html":
/*!*************************************************!*\
  !*** ./src/app/childvalue/childvalue.page.html ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>Add Child</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-item>\n    <ion-label position=\"floating\">Child Name</ion-label>\n    <ion-input></ion-input>\n  </ion-item>\n\n  <ion-item>\n      <ion-label position=\"floating\">Father Name</ion-label>\n      <ion-input></ion-input>\n    </ion-item>\n    <ion-item>\n      <ion-label position=\"floating\">Mother Name</ion-label>\n      <ion-input></ion-input>\n    </ion-item>\n    <ion-item>\n      <ion-label position=\"floating\">Phone Number</ion-label>\n      <ion-input type=\"Number\"></ion-input>\n    </ion-item>\n    <ion-item>\n      <ion-label position=\"floating\">Age</ion-label>\n      <ion-input type=\"Number\"></ion-input>\n    </ion-item>\n        <ion-button color=\"primary\" class=\"margin-top\" type=\"round\" expand=\"block\"  routerDirection=\"root\">\n      Submit\n    </ion-button>\n  \n</ion-content>\n"

/***/ }),

/***/ "./src/app/childvalue/childvalue.page.scss":
/*!*************************************************!*\
  !*** ./src/app/childvalue/childvalue.page.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".margin-top {\n  margin-top: 20px;\n  margin-left: 80px;\n  margin-right: 80px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY2hpbGR2YWx1ZS9EOlxcZ293cmktbmVzdC9zcmNcXGFwcFxcY2hpbGR2YWx1ZVxcY2hpbGR2YWx1ZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxnQkFBZTtFQUNmLGlCQUFpQjtFQUNqQixrQkFBa0IsRUFBQSIsImZpbGUiOiJzcmMvYXBwL2NoaWxkdmFsdWUvY2hpbGR2YWx1ZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubWFyZ2luLXRvcHtcclxuICAgIG1hcmdpbi10b3A6MjBweDtcclxuICAgIG1hcmdpbi1sZWZ0OiA4MHB4O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA4MHB4O1xyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/childvalue/childvalue.page.ts":
/*!***********************************************!*\
  !*** ./src/app/childvalue/childvalue.page.ts ***!
  \***********************************************/
/*! exports provided: ChildvaluePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChildvaluePage", function() { return ChildvaluePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var ChildvaluePage = /** @class */ (function () {
    function ChildvaluePage() {
    }
    ChildvaluePage.prototype.ngOnInit = function () {
    };
    ChildvaluePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-childvalue',
            template: __webpack_require__(/*! ./childvalue.page.html */ "./src/app/childvalue/childvalue.page.html"),
            styles: [__webpack_require__(/*! ./childvalue.page.scss */ "./src/app/childvalue/childvalue.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], ChildvaluePage);
    return ChildvaluePage;
}());



/***/ })

}]);
//# sourceMappingURL=childvalue-childvalue-module.js.map